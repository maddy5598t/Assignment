#include <myheader.h>

static void process_display_exit_code(int exitstatus)
        {
        cout<<"Interrupt signal ("<<exitstatus<<") received"<<endl;
        }

static void signalHandler(int ID)
        {
        cout<<"ID : "<<ID<<endl;
        }
void RegisterSignal()
{
	signal(SIGINT, process_display_exit_code);
	signal(SIGCHLD, process_display_exit_code);
}

int main(int argc, char *argv[])
{
	 if(argc != 2)
        {
                cout<<"Useage: ./app input.txt"<<endl;
                exit(EXIT_FAILURE);
        }

	
	char *value = argv[1];
	int d,status;
	time_t t;
	d=fork();
	if(d<0){
		perror("fork() error");
		exit(EXIT_FAILURE);
	}
    	else if(d==0){
	
	cout<<"Child starts writing to a file"<<endl;
	writing(value);
	cout<<"writing Comleted"<<endl;
	sleep(20);
	exit(EXIT_FAILURE);
	}
	
	else
	{
	 
		do{
			if((d = waitpid(d,&status,0)) == -1)
			{
				signal(SIGCHLD, signalHandler);
				perror("wait() error");
			}
			else if(d == 0){
				time(&t);
				cout<<"\nChild is still running at "<<ctime(&t)<<endl;
				sleep(5);
			}
			else
			{
				signal(SIGCHLD, process_display_exit_code);
				if(WIFEXITED(status)){
					
					cout<<"child exited with the status : "<<WEXITSTATUS(status)<<endl;
				}
				else if(WIFSIGNALED(status)){
					signal(SIGCHLD, process_display_exit_code);
					cout<<"Signaled: "<<status<<endl;
				}
			else
				cout<<"Child did not exit successfully"<<endl;
	cout<<"Parent starts"<<endl;
	reading(value);
	cout<<"Reading ends"<<endl;
}
}while(d == 0);
	
}	
return 0;

}
