#include <myheader.h>
	
	

	fstream fs;	
	void writing(char* value){
        string line;

      
        fs.open(value, ios::out);
        if(!fs)
        {
                cout<<"Unable to open the input file(Writing)"<<endl;
                exit(EXIT_FAILURE);
        }

        for(int i=0;i<2;i++)
        {

                getline(cin, line);
                fs<<line<<endl;
        }
        fs.close();
	}
	
	void reading(char* value){
	string line;
	fs.open(value, ios::in);
        if(!fs)
        {
                cout<<"Unable to open the input file(Reading)"<<endl;
                exit(EXIT_FAILURE);
        }

        line ="";
        while(getline(fs, line)){
                cout<<line<<endl;
                line="";
        }
}	

