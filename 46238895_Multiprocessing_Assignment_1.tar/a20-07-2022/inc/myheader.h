#pragma once

#include <iostream>
#include <csignal>
#include <cstring>
#include <cstdio>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fstream>
#include <string>
#define MAXBUFF 1024
#include <time.h>

using namespace std;

void writing(char*);
void reading(char*);
