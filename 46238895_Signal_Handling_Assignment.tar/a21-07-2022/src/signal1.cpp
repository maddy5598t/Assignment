
#include <iostream>
#include <signal.h>
#include <cstring>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fstream>
#include <string>
#include <time.h>

#define MAXBUFF 1024

using namespace std;


static void func1(int signum)
{
	//cout<<"Sig Number: "<<signum<<endl;
	switch(signum)
	{
		case SIGSEGV:
			cout<<"Sig Number: "<<signum<<endl;
			cout<<"Seg fault error occured"<<endl;
			exit(EXIT_FAILURE);
			break;

		case SIGUSR1:
			cout<<"Welcome User!"<<endl;
			break;

		case SIGHUP:
			cout<<"SIGNAL HANG UP occured! : "<<signum<<endl;
			break;

		default:
			cout<<"\nUnhandled signal : "<<signum<<endl;

	}
	
}


void mystrcat(char *s1, char *s2)
{
	int i;
	signal(SIGSEGV,func1);
	
	for(i=0;i<strlen(s2);i++)
		s1[i] = s2[i];
	s1[i] = '\0';
}

int main()
{
	sighandler_t ret = signal(SIGUSR1,func1);
	signal(SIGHUP,func1);

	if(ret == SIG_ERR)
	{
		perror("signal() error");
		exit(EXIT_FAILURE);
	}

	if(raise(SIGUSR1) != 0)
	{
		perror("raise() error");
		exit(EXIT_FAILURE);
	}
	char *s1, s2[20];
	cin>>s2;
	char *s3 = NULL;
	s1 = new char[strlen(s2)+1];
	mystrcat(s1, s3);

	cout<<"String 1: "<<s1<<endl;
	cout<<"String 2: "<<s2<<endl;

	return EXIT_SUCCESS;

}
